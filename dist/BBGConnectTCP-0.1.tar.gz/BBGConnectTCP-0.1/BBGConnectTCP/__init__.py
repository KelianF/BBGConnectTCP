# Inside of __init__.py
from BBGConnectTCP.Client import BBGRequest